# LINEPY
LINEPY but QrCode login was fixed.

Thanks to [Crash-override404](https://github.com/crash-override404/linepy-modified) for original LINEPY.

# Please do not replace the text anything but sc.
# Ini sc gratisan tolong hargain yg buat dict!
# Remake by Yepz
# Id : Myyepz
# Thanks to team hello world
# -*- coding: utf-8 -*-
'''[
Free to use, all credits belong to me, Zero Cool.
Do not sell or rent it!
© 2018 Self Bot
'''
from important import *
import pytz, datetime, time, timeit, random, sys, ast, re, os, json, subprocess, threading, string, codecs, requests, ctypes, urllib, wikipedia, html5lib
from datetime import timedelta, date
from datetime import datetime
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
import requests

# Setup Argparse
parser = argparse.ArgumentParser(description='Selfbot Self Bot')
parser.add_argument('-t', '--token', type=str, metavar='', required=False, help='Token | Example : Exxxx')
parser.add_argument('-e', '--email', type=str, default='', metavar='', required=False, help='Email Address | Example : example@xxx.xx')
parser.add_argument('-p', '--passwd', type=str, default='', metavar='', required=False, help='Password | Example : xxxx')
parser.add_argument('-a', '--apptype', type=str, default='', metavar='', required=False, choices=list(ApplicationType._NAMES_TO_VALUES), help='Application Type | Example : CHROMEOS')
parser.add_argument('-s', '--systemname', type=str, default='', metavar='', required=False, help='System Name | Example : Chrome_OS')
parser.add_argument('-c', '--channelid', type=str, default='', metavar='', required=False, help='Channel ID | Example : 1341209950')
parser.add_argument('-T', '--traceback', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Using Traceback | Use : True/False')
parser.add_argument('-S', '--showqr', type=str2bool, nargs='?', default=False, metavar='', required=False, const=True, choices=[True, False], help='Show QR | Use : True/False')
args = parser.parse_args()


# Login Client
listAppType = ['DESKTOPWIN', 'DESKTOPMAC', 'IOSIPAD', 'CHROMEOS']
try:
    print ('##----- LOGIN CLIENT -----##')
    line = None
    if args.apptype:
        tokenPath = Path('authToken.txt')
        if tokenPath.exists():
            tokenFile = tokenPath.open('r')
        else:
            tokenFile = tokenPath.open('w+')
        savedAuthToken = tokenFile.read().strip()
        authToken = savedAuthToken if savedAuthToken and not args.token else args.token
        idOrToken = authToken if authToken else args.email
        try:
            line = LINE(idOrToken, args.passwd, appType=args.apptype, systemName=args.systemname, channelId=args.channelid, showQr=args.showqr)
            tokenFile.close()
            tokenFile = tokenPath.open('w+')
            tokenFile.write(line.authToken)
            tokenFile.close()
        except TalkException as talk_error:
            if args.traceback: traceback.print_tb(talk_error.__traceback__)
            sys.exit('++ Error : %s' % talk_error.reason.replace('_', ' '))
        except Exception as error:
            if args.traceback: traceback.print_tb(error.__traceback__)
            sys.exit('++ Error : %s' % str(error))
    else:
        for appType in listAppType:
            tokenPath = Path('authToken.txt')
            if tokenPath.exists():
                tokenFile = tokenPath.open('r')
            else:
                tokenFile = tokenPath.open('w+')
            savedAuthToken = tokenFile.read().strip()
            authToken = savedAuthToken if savedAuthToken and not args.token else args.token
            idOrToken = authToken if authToken else args.email
            try:
                line = LINE(idOrToken, args.passwd, appType=appType, systemName=args.systemname, channelId=args.channelid, showQr=args.showqr)
                tokenFile.close()
                tokenFile = tokenPath.open('w+')
                tokenFile.write(line.authToken)
                tokenFile.close()
                break
            except TalkException as talk_error:
                print ('++ Error : %s' % talk_error.reason.replace('_', ' '))
                if args.traceback: traceback.print_tb(talk_error.__traceback__)
                if talk_error.code == 1:
                    continue
                sys.exit(1)
            except Exception as error:
                print ('++ Error : %s' % str(error))
                if args.traceback: traceback.print_tb(error.__traceback__)
                sys.exit(1)
except Exception as error:
    print ('++ Error : %s' % str(error))
    if args.traceback: traceback.print_tb(error.__traceback__)
    sys.exit(1)

if line:
    print ('++ Auth Token : %s' % line.authToken)
    print ('++ Timeline Token : %s' % line.tl.channelAccessToken)
    print ('##----- LOGIN CLIENT (Success) -----##')
else:
    sys.exit('##----- LOGIN CLIENT (Failed) -----##')

settingsOpen = codecs.open("temp.json","r","utf-8")

myMid = line.profile.mid
programStart = time.time()
oepoll = OEPoll(line)
tmp_text = []
lurking = {}
tokenz= {}
ingame = {
    "status": False,
    "msgWon": "الف مبروك لقد فزت @! \n للعب مره اخره ارسل ~{ الاسرع}"
    
    }

ingameOne = {
    "status": False,
    "msgWon": "الف مبروك لقد فزت @! \n للعب مره اخره ارسل ~{ حزوره}"
    
    }
noobcoderProfile = line.getProfile()
noobcoderSettings = line.getSettings()
noobcoderPoll = OEPoll(line)
noobcoderMID = line.getProfile().mid
myAdmin = ["ub0acf183298a7bbb9dd4945ed122fac1"]
myAdmin2 = ["u362061b80c44a9dab297735c065e24be"]
admin =["ub0acf183298a7bbb9dd4945ed122fac1"]
settings1 = json.load(settingsOpen)



# ============================================================================

settings = livejson.File('setting.json', True, False, 4)

# ===============================================================================


liffnya = {
    "ttt": "line://app/1602687308-GXq4Vvk9?type=text&text=",
}

#Yepzgans
bool_dict = {
    True: ['Yes', 'Active', 'Success', 'Open', 'On'],
    False: ['No', 'Not Active', 'Failed', 'Close', 'Off']
}

# Backup profile
profile = line.getContact(myMid)
settings['myProfile']['displayName'] = profile.displayName
settings['myProfile']['statusMessage'] = profile.statusMessage
settings['myProfile']['pictureStatus'] = profile.pictureStatus
coverId = line.profileDetail['result']['objectId']
settings['myProfile']['coverId'] = coverId


# Check Json Data
if not settings:
    print ('##----- LOAD DEFAULT JSON -----##')
    try:
        default_settings = line.server.getJson('https://17hosting.id/default.json')
        settings.update(default_settings)
        print ('##----- LOAD DEFAULT JSON (Success) -----##')
    except Exception:
        print ('##----- LOAD DEFAULT JSON (Failed) -----##')


def restartProgram():
    print ('##----- PROGRAM RESTARTED -----##')
    python = sys.executable
    os.execl(python, python, *sys.argv)

def logError(error, write=True):
    errid = str(random.randint(100, 999))
    filee = open('tmp/errors/%s.txt'%errid, 'w') if write else None
    if args.traceback: traceback.print_tb(error.__traceback__)
    if write:
        traceback.print_tb(error.__traceback__, file=filee)
        filee.close()
        with open('errorLog.txt', 'a') as e:
            e.write('\n%s : %s'%(errid, str(error)))
    print ('++ Error : {error}'.format(error=error))

def command(text):
    pesan = text.lower()
    if settings['setKey']['status']:
        if pesan.startswith(settings['setKey']['key']):
            cmd = pesan.replace(settings['setKey']['key'],'')
        else:
            cmd = 'Undefined command'
    else:
        cmd = text.lower()
    return cmd

#=====================================================
def runtime(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours, 24)
    return '%02d d %02d h %02d m %02d s' % (days, hours, mins, secs)

#=====================================================
def timeChange(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    days, hours = divmod(hours,24)
    weeks, days = divmod(days,7)
    months, weeks = divmod(weeks,4)
    text = ""
    if months != 0: text += "%02d αч" % (months)
    if weeks != 0: text += " %02d Hαғtα" % (weeks)
    if days != 0: text += " %02d Güи" % (days)
    if hours !=  0: text +=  " %02d Sααт" % (hours)
    if mins != 0: text += " %02d Dαкiкα" % (mins)
    if secs != 0: text += " %02d Sαniчє" % (secs)
    if text[0] == " ":
        text = text[1:]
    return text

def foro(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "styles": {
    "footer": {
    "backgroundColor": '#000000'
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
    "cornerRadius": "xl",
    "borderWidth": "4px",
    "borderColor": "#FFFFFF",
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": thedata2["flag_pic"],
    "size": "md"
    },
    {
    "type": "text",
    "text": text,
    "color": "#FFFFFF",
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "md"
    },
    {
    "type": "icon",
    "url": thedata2["flag_pic"],
    "size": "md"
    },
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)
 #=====================================================
def mekz(to, isi):
    data = {
        "type": "flex",
        "altText": "احبك ارهابي",
        "contents": {
            "type": "carousel",
            "contents": [
              {
                "type": "bubble",
                "body": {
                "type": "box",
                "layout": "vertical",
                "cornerRadius": "xl",
                "borderWidth": "4px",
                "borderColor": "#ffffff",
                "contents": [
                  {
                    "type": "image",
                    "url": thedata2["flag_pic"],
                    "size": "full",
                    "aspectMode": "cover",
                    "aspectRatio": "9:16",
                    "gravity": "top"
                  },
                  {
                    "type": "box",
                    "layout": "vertical",
                    "contents": [
                      {
                        "type": "box",
                        "layout": "baseline",
                        "contents": [
                          {
                            "type": "text",
                            "text": isi,
                            "wrap": True,
                            "align": "start",
                            "gravity": "center",
                            "weight": "bold",
                            "color": "#ffffff",
                            "size": "sm",
                            "flex": 0
                          }
                        ],
                        "spacing": "lg"
                      },
                      {
                        "type": "box",
                        "layout": "vertical",
                        "contents": [
                          {
                            "type": "filler"
                          },
                          {
                            "type": "box",
                            "layout": "baseline",
                            "contents": [
                              {
                                "type": "filler"
                              },
                              {
                                "type": "text",
                                "text": "ArHaBy*🔥",
                                "action": {
                                  "type": "uri",
                                  "uri": "http://line.me/ti/p/~arhaby"
                                },
                                "color": "#ffffff",
                                "flex": 0,
                                "offsetTop": "-2px"
                              },
                              {
                                "type": "filler"
                              }
                            ],
                            "spacing": "sm"
                          },
                          {
                            "type": "filler"
                          }
                        ],
                        "borderWidth": "1px",
                        "cornerRadius": "4px",
                        "spacing": "sm",
                        "borderColor": "#ffffff",
                        "margin": "xxl",
                        "height": "40px"
                      }
                    ],
                    "position": "absolute",
                    "offsetBottom": "0px",
                    "offsetStart": "0px",
                    "offsetEnd": "0px",
                    "backgroundColor": "#000000cc",
                    "paddingAll": "20px",
                    "paddingTop": "18px"
                  }
                ],
                "paddingAll": "0px"
            }
          }
        ]
      }
    }
    sendTemplate(to, data)

def changeVideoAndPictureProfile(pict, vids):
    try:
        files = {'file': open(vids, 'rb')}
        obs_params = line.genOBSParams({'oid': myMid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4', 'name': 'Hello_World.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return "Failed update profile"
        line.updateProfilePicture(pict, 'vp')
        return "Success update profile"
    except Exception as e:
        raise Exception("Error change video and picture profile %s"%str(e))
        
def changeProfileVideo(to):
    if settings['changevp']['picture'] == None:
        return yepzLove(to, "Foto tidak ditemukan")
    elif settings['changevp']['video'] == None:
        return yepzLove(to, "Video tidak ditemukan")
    else:
        path = settings['changevp']['video']
        files = {'file': open(path, 'rb')}
        obs_params = line.genOBSParams({'oid': line.getProfile().mid, 'ver': '2.0', 'type': 'video', 'cat': 'vp.mp4'})
        data = {'params': obs_params}
        r_vp = line.server.postContent('{}/talk/vp/upload.nhn'.format(str(line.server.LINE_OBS_DOMAIN)), data=data, files=files)
        if r_vp.status_code != 201:
            return yepzLove(to, "Gagal update profile")
        path_p = settings['changevp']['picture']
        settings['changevp']['status'] = False
        line.updateProfilePicture(path_p, 'vp')

def genImageB64(path):
    with open(path, 'rb') as img_file:
        encode_str = img_file.read()
        b64img = base64.b64encode(encode_str)
        return b64img.decode('utf-8')

def genUrlB64(url):
    return base64.b64encode(url.encode('utf-8')).decode('utf-8')
    
#DEFFTEMPLATE
def sendTemplate(group, data):
    warna1 = ("#0000FF","#000000","#05092A","#00BFFF","#708090","#800000","#FF0000","#E9967A","#DDA0DD")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(group)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def sendTemplate(to, data):
    warna1 = ("#0000FF","#000000","#05092A","#00BFFF","#708090","#800000","#FF0000","#E9967A","#DDA0DD")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

def bcTemplate(gr, data):
    warna1 = ("#0000FF","#000000","#05092A","#00BFFF","#708090","#800000","#FF0000","#E9967A","#DDA0DD")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(gr)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
def tagdia(to, text="",ps='', mids=[]):
        arrData = ""
        arr = []
        mention = "@zeroxyuuki "
        if mids == []:
            raise Exception("Invalid mids")
        if "@!" in text:
            if text.count("@!") != len(mids):
                raise Exception("Invalid mids")
            texts = text.split("@!")
            textx = ''
            h = ''
            for mid in range(len(mids)):
                h+= str(texts[mid].encode('unicode-escape'))
                textx += str(texts[mid])
                if h != textx:slen = len(textx)+h.count('U0');elen = len(textx)+h.count('U0') + 13
                else:slen = len(textx);elen = len(textx) + 13
                arrData = {'S':str(slen), 'E':str(elen), 'M':mids[mid]}
                arr.append(arrData)
                textx += mention
            textx += str(texts[len(mids)])
        else:
            textx = ''
            slen = len(textx)
            elen = len(textx) + 18
            arrData = {'S':str(slen), 'E':str(elen - 4), 'M':mids[0]}
            arr.append(arrData)
            textx += mention + str(text)
        line.sendMessage(to, textx, {'MSG_SENDER_NAME': line.getContact(ps).displayName,'MSG_SENDER_ICON': "http://dl.profile.line-cdn.net/" + line.getContact(ps).pictureStatus,'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
#=====================================================================

def bcTemplate2(friend, data):
    warna1 = ("#0000FF","#000000","#05092A","#00BFFF","#708090","#800000","#FF0000","#E9967A","#DDA0DD")
    warnanya1 = random.choice(warna1)
    xyz = LiffChatContext(friend)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))
    
def sendflex(to, data):
    n1 = LiffChatContext(to)
    n2 = LiffContext(chat=n1)
    view = LiffViewRequest('1602687308-GXq4Vvk9', n2)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    data = {"messages":[data]}
    requests.post(url, headers=headers, data=json.dumps(data))

uagent = {
    "User-Agent": "Mozilla\t5.0"
}

def sendCarousel(to, data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)                                    
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)
    
def sendCarousel(to,col):
    col = json.dumps(col)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=col, headers=headers)
    
def sendFooter(to, isi):
    data = {
        "type": "text",
        "text": isi,
        "sentBy": {
            "label": "</ Error >",
            "iconUrl": "https://obs.line-scdn.net/{}".format(line.getContact("ub0acf183298a7bbb9dd4945ed122fac1").pictureStatus),
            "linkUrl": "line://nv/profilePopup/mid=ub0acf183298a7bbb9dd4945ed122fac1"
        }
    }
    sendTemplate(to, data)
    
def sendCarousel(to, data):
    data = json.dumps(data)
    xyz = LiffChatContext(to)
    xyzz = LiffContext(chat=xyz)
    view = LiffViewRequest('1602687308-GXq4Vvk9', xyzz)
    token = line.liff.issueLiffView(view)
    url = 'https://api.line.me/message/v3/share'
    headers = {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer %s' % token.accessToken
    }
    return requests.post(url, data=data, headers=headers)

def yepzLove(to, text):
    data = {
    "type": "flex",
    "altText": text,
    "contents": {
    "type": "bubble",
    "size": "micro",
    "styles": {
    "footer": {
    "backgroundColor": '#ff000000'
    }
    },
    "footer": {
    "type": "box",
    "layout": "vertical",
    "spacing": "sm",
    "contents": [
    {
    "type": "box",
    "layout": "baseline",
    "contents": [
    {
    "type": "icon",
    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
    "size": "xxs"
    },
    {
    "type": "text",
    "text": text,
    "color": "#000000",
    "gravity": "center",
    "align":"center",
    "wrap": True,
    "size": "xxs",
    },
    {
    "type": "icon",
    "url": "https://obs.line-scdn.net/{}".format(line.getContact(myMid).pictureStatus),
    "size": "xxs",
    }, 
    ]
    }
    ]
    }
    }
    }
    sendTemplate(to, data)

def removeCmd(text, key=''):
    if key == '':
        setKey = '' if not settings['setKey']['status'] else settings['setKey']['key']
    else:
        setKey = key
    text_ = text[len(setKey):]
    sep = text_.split(' ')
    return text_[len(sep[0] + ' '):]

def multiCommand(cmd, list_cmd=[]):
    if True in [cmd.startswith(c) for c in list_cmd]:
        return True
    else:
        return False

def replaceAll(text, dic):
    try:
        rep_this = dic.items()
    except:
        rep_this = dic.iteritems()
    for i, j in rep_this:
        text = text.replace(i, j)
    return text

def parsingRes(res):
    result = ''
    textt = res.split('\n')
    for text in textt:
        if True not in [text.startswith(s) for s in ['╭', '├', '│', '╰']]:
            result += '\n│ ' + text
        else:
            if text == textt[0]:
                result += text
            else:
                result += '\n' + text
    return result

def mentionMembers(to, mids=[]):
    if myMid in mids: mids.remove(myMid)
    parsed_len = len(mids)//20+1
    result = '╭───「 الاعضاء 」\n'
    mention = '@zeroxyuuki\n'
    no = 0
    for point in range(parsed_len):
        mentionees = []
        for mid in mids[point*20:(point+1)*20]:
            no += 1
            result += '│ %i. %s' % (no, mention)
            slen = len(result) - 12
            elen = len(result) + 3
            mentionees.append({'S': str(slen), 'E': str(elen - 4), 'M': mid})
            if mid == mids[-1]:
                result += '╰───「 سلف ارهابي 」\n'
        if result:
            if result.endswith('\n'): result = result[:-1]
            line.sendMessage(to, result, {'MENTION': json.dumps({'MENTIONEES': mentionees})}, 0)
        result = ''
def ClonerV2(to):
    try:
        contact = line.getContact(to)
        profile = line.profile
        profileName = line.profile
        profileStatus = line.profile
        profileName.displayName = contact.displayName
        profileStatus.statusMessage = contact.statusMessage
        line.updateProfile(profileName)
        line.updateProfile(profileStatus)
        profile.pictureStatus = line.downloadFileURL('http://dl.profile.line-cdn.net/{}'.format(contact.pictureStatus, 'path'))
        if line.getProfileCoverId(to) is not None:
            line.updateProfileCoverById(line.getProfileCoverId(to))
        line.updateProfilePicture(profile.pictureStatus)
        print("Success Clone Profile {}".format(contact.displayName))
        return line.updateProfile(profile)
        if contact.videoProfile == None:
            return "Get Video Profile"
        path2 = "http://dl.profile.line-cdn.net/" + profile.pictureStatus
        line.updateProfilePicture(path2, 'vp')
    except Exception as error:
        print(error)
def cloneProfile(mid):
    contact = line.getContact(mid)
    profile = line.getProfile()
    profile.displayName, profile.statusMessage = contact.displayName, contact.statusMessage
    line.updateProfile(profile)
    if contact.pictureStatus:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + contact.pictureStatus)
        line.updateProfilePicture(pict)
    coverId = line.getProfileDetail(mid)['result']['objectId']
    line.updateProfileCoverById(coverId)

def backupProfile():
    profile = line.getContact(myMid)
    settings['myProfile']['displayName'] = profile.displayName
    settings['myProfile']['pictureStatus'] = profile.pictureStatus
    settings['myProfile']['statusMessage'] = profile.statusMessage
    coverId = line.getProfileDetail()['result']['objectId']
    settings['myProfile']['coverId'] = str(coverId)

def restoreProfile():
    profile = line.getProfile()
    profile.displayName = settings['myProfile']['displayName']
    profile.statusMessage = settings['myProfile']['statusMessage']
    line.updateProfile(profile)
    if settings['myProfile']['pictureStatus']:
        pict = line.downloadFileURL('http://dl.profile.line-cdn.net/' + settings['myProfile']['pictureStatus'])
        line.updateProfilePicture(pict)
    coverId = settings['myProfile']['coverId']
    line.updateProfileCoverById(coverId)

def executeCmd(msg, text, txt, cmd, msg_id, receiver, sender, to, setKey):



    if cmd == 'tagall':
        members = []
        if msg.toType == 1:
            room = line.getCompactRoom(to)
            members = [mem.mid for mem in room.contacts]
        elif msg.toType == 2:
            group = line.getCompactGroup(to)
            members = [mem.mid for mem in group.members]
        else:
            return yepzLove(to, 'Failed mentionall members, use this command only on room or group chat')
        if members:
            mentionMembers(to, members)


# =====================================================================
def executeOp(op):
    try:
        print ('++ Operation : ( %i ) %s' % (op.type, OpType._VALUES_TO_NAMES[op.type].replace('_', ' '))) 
        if op.type == 13:
            line.acceptGroupInvitation(op.param1)
        if op.type == 26:
            msg      = op.message
            text     = str(msg.text)
            msg_id   = msg.id
            receiver = msg.to
            sender   = msg._from
            to       = sender if not msg.toType and sender != myMid else receiver
            txt      = text.lower()

            
            if msg.contentType == 0: # Content type is text
                # =================================الاسرع===========================================
                if '/ti/g/' in text and settings['autoJoin']['ticket']:
                    regex = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                    links = regex.findall(text)
                    tickets = []
                    gids = line.getGroupIdsJoined()
                    for link in links:
                        if link not in tickets:
                            tickets.append(link)
                    for ticket in tickets:
                        try:
                            group = line.findGroupByTicket(ticket)
                        except:
                            continue
                        if group.id in gids:
                            yepzLove(to, 'I\'m aleady on group ' + group.name)
                            continue
                        line.acceptGroupInvitationByTicket(group.id, ticket)
                        if settings['autoJoin']['reply']:
                            if '@!' not in settings['autoJoin']['message']:
                                yepzLove(to, settings['autoJoin']['message'])
                            else:
                                line.sendMentionV2(to, settings['autoJoin']['message'], [sender])
                        yepzLove(to, 'Success join to group ' + group.name)
                if text == ("حبيبتي"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "هلاحبيبي")
                if text == ("منو حبيبتي"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "انا يروحي")
                if text == ("انطيني بوسه"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "مواحححححح")
                if text == ("ارهابي"):
                    line.sendMessage(to, "حبيبي هذا شتبي منه")
                if text == ("حبيبتي منشني الكل"):
                    if msg._from in myAdmin:
                        members = []
                        if msg.toType == 1:
                            room = line.getCompactRoom(to)
                            members = [mem.mid for mem in room.contacts]
                        elif msg.toType == 2:
                            group = line.getCompactGroup(to)
                            members = [mem.mid for mem in group.members]
                        else:
                            return line.sendMessage(to, 'اسف حبيبي ماكدرت')
                        if members:
                            mentionMembers(to, members)                        
                if text == ("مشتاقلج"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "اني هم يروحي مشتاقتلك")                                                  
                if text == ("العنيفه"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "لاتتكلم معاها انا بغار عليك")                   
                if text == ("احبج"):
                    if msg._from in myAdmin:
                        line.sendMessage(to, "اني هم احبك روحي")
                if text == ("احبج"):
                    if msg._from in myAdmin2:
                        line.sendMessage(to, "ماحبك انا احب ارهابي")

# =================================الاسرع===========================================
                if text == ("الاسرع"):
                    gifna = ('اسرع واحد يرتبها ~ {ى ش س ف ت م}', 'اسرع واحد يرتبها ~ {س ت ا ن و ك ر ي}', 'اسرع واحد يرتبها ~ {س ر و ح}', 'اسرع واحد يرتبها ~ {ر ت ق ب ا ه ل}','اسرع واحد يرتبها ~ {ه ط م ر ق}','اسرع واحد يرتبها ~ {ن ا و ا ل}','اسرع واحد يرتبها ~ {ه ط م ح}','اسرع واحد يرتبها ~ {ح ا ه س}','اسرع واحد يرتبها ~ {ق ع ا ل ر ا}','اسرع واحد يرتبها ~ {ب ت ت ي ه}','اسرع واحد يرتبها ~ {ا ت ن ر ن ي ت}','اسرع واحد يرتبها ~ {ه م د ر س}','اسرع واحد يرتبها ~ {ه ر س ي ا}','اسرع واحد يرتبها ~ {خ ب ط م}','اسرع واحد يرتبها ~ {ر ا ر ا د}','اسرع واحد يرتبها ~ {ر ج س}','اسرع واحد يرتبها ~ {ه ق ن ف}','اسرع واحد يرتبها ~ {ج ج ا د ه}','اسرع واحد يرتبها ~ {ص ا ب}','اسرع واحد يرتبها ~ {ر ا ط ي ه}','اسرع واحد يرتبها ~ {ه ك ه و}','اسرع واحد يرتبها ~ {ط ب و ا خ ط}','اسرع واحد يرتبها ~ {ك س م ه}','اسرع واحد يرتبها ~ {ت ف ل ز ا}','اسرع واحد يرتبها ~ {ح ف ا ت}','اسرع واحد يرتبها ~ {ن م و ل س}','اسرع واحد يرتبها ~ {ه ن ف ي س}','اسرع واحد يرتبها ~ {غ ه ر ف}')
                    gifnay = random.choice(gifna)
                    line.sendMessage(to, gifnay)
                    ingame["status"] = True


                if text == ('برتقاله'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('كرستيانو'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                                    
                if text == ('مستشفى'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                                                        
                if text == ('مطرقه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('سحور'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('الوان'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('محطه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('ساحه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('العراق'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('بتيته'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('انترنيت'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('مدرسه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False                
                if text == ('سياره'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('مطبخ'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('رادار'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False
                if text == ('جسر'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False
                if text == ('قنفه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False
                if text == ('دجاجه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False
                if text == ('باص'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('طياره'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('كهوه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('اخطبوط'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('سمكه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('تلفاز'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False    
                if text == ('تفاح'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False
                if text == ('سلمون'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False   

                if text == ('سفينه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False

                if text == ('غرفه'):
                    if ingame["status"] == True:
                        line.sendMentionV2(to, ingame['msgWon'], [sender])    
                        ingame["status"] = False   

# =================================حزوره===========================================
                if text == ("حزوره"):
                    gifna = ('اسرع واحد يحل الحزوره ↓ \n  {ما هو الشيئ الذي يرفع اثقال ولا يقدر يرفع مسمار ؟}','اسرع واحد يحل الحزوره ↓ \n  {ما الشيئ الذي له اوراق وليس له جذور ؟}','اسرع واحد يحل الحزوره ↓ \n  {انا ابن الماء فان تركوني في الماء مت فمن انا ؟}','اسرع واحد يحل الحزوره ↓ \n  {ما هو الشيئ الذي كلما خطا خطوه فقد شيئا من ذيله ؟ }','اسرع واحد يحل الحزوره ↓ \n  {ما هو الشيء الذي كلما طال قصر ؟ }','اسرع واحد يحل الحزوره ↓ \n  {كلي ثقوب ومع ذالك احفض الماء فمن اكون ؟}', 'اسرع واحد يحل الحزوره ↓ \n  {ما هو الشيئ اذا أخذنا منه ازداد وكبر ؟}', 'اسرع واحد يحل الحزوره ↓ \n  {اسير بلا رجلين ولا ادخل الا بالاذنين فمن انا ؟}', 'اسرع واحد يحل الحزوره ↓ \n  {اخوان لا يستطيعان تمضيه اكثر من دقيقه معا فما هما ؟}', 'اسرع واحد يحل الحزوره ↓ \n  {ما هو الشيئ الذي لا يمشي الا بالضرب ؟}')
                    gifnay = random.choice(gifna)
                    line.sendMessage(to, gifnay)
                    ingameOne["status"] = True
                if text == ('البحر'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('الكتاب'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('الثلج'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('الابره'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('العمر'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('اسفنجه'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('الحفره'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('الصوت'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('عقرب الساعه'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False   
                if text == ('المسمار'):
                    if ingameOne["status"] == True:
                        line.sendMentionV2(to, ingameOne['msgWon'], [sender])    
                        ingameOne["status"] = False  



    except TalkException as talk_error:
        logError(talk_error)
        if talk_error.code in [7, 8, 20]:
            sys.exit(1)
    except KeyboardInterrupt:
        sys.exit('##---- KEYBOARD INTERRUPT -----##')
    except Exception as error:
        logError(error)

def runningProgram():
    while True:
        try:
            ops = oepoll.singleTrace(count=50)
        except TalkException as talk_error:
            logError(talk_error)
            if talk_error.code in [7, 8, 20]:
                sys.exit(1)
            continue
        except KeyboardInterrupt:
            sys.exit('##---- KEYBOARD INTERRUPT -----##')
        except Exception as error:
            logError(error)
            continue
        if ops:
            for op in ops:
                executeOp(op)
                oepoll.setRevision(op.revision)

if __name__ == '__main__':
    print ('##---- RUNNING PROGRAM -----##')
    runningProgram()
